# CPP 抢票脚本（学习交流用）

基于 CPP（allcpp.cn）移动端接口实现的自动抢票脚本，支持多票种优先级、自动重试与回流捡漏。

> 本脚本仅供学习交流与个人购票使用，请勿用于商业倒卖或对平台造成异常负担。

## 文件说明

- `grab.py`：主脚本（Python 3，仅标准库，无需安装依赖）
- `config.example.json`：配置模板（**复制为 config.json 后填入自己的抓包数据**）

## 使用方法

1. 用 Fiddler 抓取 CPP App 的请求，从任意 `allcpp.cn` 请求中获取：
   - URL 里的 `token` 参数
   - 请求头里的 `Cookie`
   - `purchaser/getList.do` 响应中的购票人 ID
2. 将 `config.example.json` 复制为 `config.json`，填入自己的 token / Cookie / deviceId / 购票人 ID
3. 按需修改 `tickets` 列表（票种 ID、名称、价格需与 `getTicketTypeList.do` 响应一致，避免抢错票）

## 命令

```bat
python grab.py verify     # 校验票种和购票人配置
python grab.py selftest   # 自测签名算法
python grab.py dryrun     # 打印请求内容（不发送）
python grab.py grab       # 按优先级抢票（主目标 → 备选 → 自动捡漏）
python grab.py watch      # 单独运行回流捡漏监控
```

## 签名算法说明

```text
sign = MD5(reverse(后缀) + reverse(票种ID) + reverse(随机串) + reverse(时间戳) + reverse(前缀))
```

前缀/后缀常量已内置在脚本中，来自对 App 运行内存的逆向分析。

## 注意事项

- 每个账号的 token/Cookie 是独立的，**请勿将配置文件分享给他人**
- 平台对异常高频下单有风控（HTTP 403/429），脚本已内置"400/403/429 立即停止"与低频轮询策略，请勿自行调高频率
- 票种售罄后平台可能直接下架票种，回流捡漏仅在下架前有效
