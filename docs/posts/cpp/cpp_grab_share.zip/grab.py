#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CPP 平台抢票脚本 - COMICUPG08 普通双日票 (ticketTypeId=6167)

用法:
  python grab.py selftest   # 自测签名算法
  python grab.py verify     # 校验票种信息（防止抢错票）
  python grab.py grab       # 开售瞬间抢票（需先更新 config.json 里的 token/cookie）
"""

import argparse
import email.utils
import hashlib
import json
import os
import random
import ssl
import string
import sys
import time
import urllib.parse
import urllib.request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")

# 签名常量（App 3.26.4，已通过运行内存捕获 + 真实下单验证）
PREFIX = "CPP2C0T2Y5U0M7A2D9L"
SUFFIX = "MKSEDLUSHKSIJSISHMNFEDNSUYQEAVJSFWP"


def load_config(path=CONFIG_PATH):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def make_sign(ticket_type_id, nonce, timestamp):
    """生成下单签名：
    MD5(reverse(suffix) + reverse(ticketTypeId) + reverse(nonce)
        + reverse(timeStamp) + reverse(prefix))
    """
    raw = (
        SUFFIX[::-1]
        + str(ticket_type_id)[::-1]
        + nonce[::-1]
        + str(timestamp)[::-1]
        + PREFIX[::-1]
    )
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


def make_nonce(length=5):
    return "".join(random.choices(string.ascii_uppercase, k=length))


def get_purchaser_ids(cfg):
    """获取购票人 ID 字符串（支持单个或多个，多个用分隔符拼接）"""
    p = cfg.get("purchaserIds")
    if isinstance(p, (list, tuple)):
        return cfg.get("purchaserIdsSeparator", ",").join(str(x) for x in p)
    return str(p)


def build_url(cfg):
    qs = urllib.parse.urlencode(cfg["query_params"])
    return cfg["base_url"] + "?" + qs


def http_request(cfg, url, body=None, timeout=10):
    headers = dict(cfg["headers"])
    # 直连服务器，禁用系统代理（避免 Fiddler 等代理干扰）
    headers.pop("Accept-Encoding", None)
    headers.pop("Host", None)
    data = None
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=UTF-8"
    req = urllib.request.Request(
        url, data=data, headers=headers, method="POST" if body is not None else "GET"
    )
    proxy = cfg.get("proxy")
    if proxy:
        ph = urllib.request.ProxyHandler({"https": proxy, "http": proxy})
        if not cfg.get("ssl_verify", True):
            ctx = ssl._create_unverified_context()
            opener = urllib.request.build_opener(ph, urllib.request.HTTPSHandler(context=ctx))
        else:
            opener = urllib.request.build_opener(ph)
    else:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as resp:
        text = resp.read().decode("utf-8", errors="replace")
        return resp.status, text, resp.headers


def sync_time(cfg):
    """用服务器响应头 Date 校准本地时钟（多次采样取中位，扣除 RTT）
    返回 offset_ms = 服务器时间 - 本地时间"""
    url = "https://www.allcpp.cn/api/common/openscree.do?" + urllib.parse.urlencode(
        cfg["query_params"]
    )
    offsets = []
    for _ in range(5):
        try:
            t0 = time.time() * 1000
            _, _, headers = http_request(cfg, url, timeout=5)
            t1 = time.time() * 1000
            date_str = headers.get("Date")
            if date_str:
                server_ms = int(
                    email.utils.parsedate_to_datetime(date_str).timestamp() * 1000
                )
                offsets.append(server_ms - (t0 + (t1 - t0) / 2))
        except Exception:
            pass
        time.sleep(0.2)
    if offsets:
        offsets.sort()
        offset = offsets[len(offsets) // 2]
        print(f"[*] 服务器时间校准完成，偏移: {offset:+.0f} ms（{len(offsets)} 次采样中位）")
        return offset
    print("[!] 对时失败，使用本地时间")
    return 0


def get_ticket_type_list(cfg):
    """获取活动票种列表"""
    params = {
        "eventMainId": cfg.get("eventMainId"),
        "ticketMainId": 0,
        **cfg["query_params"],
    }
    url = "https://www.allcpp.cn/allcpp/ticket/getTicketTypeList.do?" + urllib.parse.urlencode(
        params
    )
    _, text, _ = http_request(cfg, url, timeout=10)
    data = json.loads(text)

    def find_list(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k in ("ticketTypeList", "ticketTypes") and isinstance(v, list):
                    return v
                r = find_list(v)
                if r:
                    return r
        elif isinstance(o, list):
            for i in o:
                r = find_list(i)
                if r:
                    return r

    return find_list(data) or []


def verify_tickets(cfg):
    """校验所有配置票种（名称/价格/开售时间），防止抢错票"""
    tickets = cfg.get("tickets")
    if not tickets:
        print("[!] 配置中没有票种")
        return False
    try:
        tl = get_ticket_type_list(cfg)
    except Exception as e:
        print(f"[!] 获取票种列表失败: {e}")
        return False
    all_ok = True
    for t in tickets:
        target = next((x for x in tl if x.get("id") == t["ticketTypeId"]), None)
        if not target:
            print(f"[!] 未找到票种 ID={t['ticketTypeId']} ({t.get('ticketName')})")
            all_ok = False
            continue
        name_ok = target.get("ticketName") == t["ticketName"]
        price_ok = target.get("ticketPrice") == t["ticketPrice"]
        start_ok = target.get("sellStartTime") == t["sellStartTime"]
        role = t.get("role", "")
        print(f"[*] {'主目标' if role=='primary' else '备选'}: "
              f"ID={target.get('id')} 名称={target.get('ticketName')} "
              f"价格={target.get('ticketPrice', 0)/100}元")
        print(f"[*]   校验: 名称{'OK' if name_ok else 'FAIL'} "
              f"价格{'OK' if price_ok else 'FAIL'} "
              f"开售时间{'OK' if start_ok else 'FAIL'}")
        if not (name_ok and price_ok and start_ok):
            all_ok = False
    if not all_ok:
        print("[!] 存在校验失败的票种，中止（防止抢错票）")
        return False
    print("[*] 全部票种校验通过")
    return True


def verify_purchasers(cfg):
    """校验购票人列表：确保配置的购票人存在且数量足够"""
    url = "https://www.allcpp.cn/allcpp/user/purchaser/getList.do?" + urllib.parse.urlencode(
        cfg["query_params"]
    )
    try:
        _, text, _ = http_request(cfg, url, timeout=10)
        data = json.loads(text)
    except Exception as e:
        print(f"[!] 获取购票人列表失败: {e}")
        return False
    if not isinstance(data, list):
        print(f"[!] 购票人列表格式异常: {str(data)[:100]}")
        return False
    configured = [str(x) for x in cfg.get("purchaserIds", [])]
    available = {str(p.get("id")): p.get("realname") for p in data}
    print(f"[*] 当前购票人 ({len(data)} 个):")
    for pid, name in available.items():
        print(f"    ID={pid} {name}")
    missing = [pid for pid in configured if pid not in available]
    if missing:
        print(f"[!] 配置的购票人不存在: {missing}")
        return False
    need = int(cfg.get("count", 1))
    if len(configured) < need:
        print(f"[!] 购票人数量({len(configured)})少于购买数量({need})")
        return False
    print(f"[*] 购票人校验通过（{len(configured)} 人购 {need} 张）")
    return True


def dryrun(cfg):
    """打印完整请求内容但不发送，用于人工核对"""
    for t in cfg.get("tickets", []):
        now_ms = int(time.time() * 1000)
        nonce = make_nonce()
        body = {
            "count": cfg["count"],
            "nonce": nonce,
            "purchaserIds": get_purchaser_ids(cfg),
            "sign": make_sign(t["ticketTypeId"], nonce, now_ms),
            "ticketTypeId": t["ticketTypeId"],
            "timeStamp": str(now_ms),
        }
        print("=" * 60)
        print(f"票种: {t.get('ticketName')} (ID={t['ticketTypeId']})")
        print("请求 URL:")
        print(build_url(cfg))
        print()
        print("请求头:")
        for k, v in cfg["headers"].items():
            print(f"  {k}: {v}")
        print()
        print("请求体:")
        print(json.dumps(body, ensure_ascii=False, indent=2))
        print()
        print("签名原始串:")
        raw = (
            SUFFIX[::-1] + str(t["ticketTypeId"])[::-1] + nonce[::-1]
            + str(now_ms)[::-1] + PREFIX[::-1]
        )
        print(f"  {raw}")
        print()
    print("=" * 60)
    print("[*] 以上为模拟请求（未发送）。请与 Fiddler 中 App 实际请求对比格式。")
    return True


def selftest():
    """用已确认的真实样本验证签名算法"""
    # 样本来自运行内存捕获 + 成功下单（ticketTypeId=6059 测试单）
    s = make_sign(6059, "QJKSL", 1786610014827)
    expected = "eee96ce028b2234dd4c2d5c3660a3b6a"
    print(f"签名自测: {s}")
    print(f"期望值:   {expected}")
    ok = s == expected
    print("结果:", "通过" if ok else "失败")
    return ok


def place_order(cfg, ticket, now_ms):
    nonce = make_nonce()
    body = {
        "count": cfg["count"],
        "nonce": nonce,
        "purchaserIds": get_purchaser_ids(cfg),
        "sign": make_sign(ticket["ticketTypeId"], nonce, now_ms),
        "ticketTypeId": ticket["ticketTypeId"],
        "timeStamp": str(now_ms),
    }
    return http_request(cfg, build_url(cfg), body=body, timeout=10)


def is_retryable(msg):
    """判断下单失败是否值得重试。
    显式售罄消息 → 不重试；排队/繁忙等瞬时错误 → 重试。
    """
    sold_out = [
        "售罄", "售完", "无票", "没有余票", "余票不足", "库存不足",
        "已抢完", "抢光", "抢空", "卖完", "票已售", "没有库存",
    ]
    if any(w in msg for w in sold_out):
        return False
    retry = [
        "排队", "繁忙", "火爆", "稍后", "重试", "网络", "超时",
        "系统", "未开始", "限流", "人数过多", "拥挤", "服务器",
    ]
    return any(w in msg for w in retry)


def save_order(cfg, ticket, result):
    account = cfg.get("account", "default")
    path = os.path.join(BASE_DIR, f"order_info_{account}.json")
    records = []
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                old = json.load(f)
            records = old if isinstance(old, list) else [old]
        except Exception:
            records = []
    records.append({
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "account": account,
        "ticketName": ticket.get("ticketName"),
        "ticketTypeId": ticket["ticketTypeId"],
        "result": result,
    })
    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)
    print(f"[+] 订单信息已保存: {path}")
    oi = result.get("orderInfo")
    if oi:
        op = os.path.join(BASE_DIR, f"orderInfo_{account}_{ticket['ticketTypeId']}.txt")
        with open(op, "w", encoding="utf-8") as f:
            f.write(oi)
        print(f"[+] 支付宝支付串已保存: {op}")
    # 常见响应字段
    for k in ("outTradeNo", "ticketName", "totalAmount"):
        if k in result:
            print(f"[+] {k}: {result[k]}")


def try_ticket(cfg, ticket, offset_ms, max_attempts=None):
    """尝试为单个票种下单，返回 True/False"""
    if max_attempts is None:
        max_attempts = cfg.get("max_attempts", 30)
    delay = cfg.get("retry_delay", 0.5)
    for attempt in range(1, max_attempts + 1):
        now_ms = int(time.time() * 1000) + offset_ms
        try:
            status, text, _ = place_order(cfg, ticket, now_ms)
            data = json.loads(text)
        except urllib.error.HTTPError as e:
            code = e.code
            if code in (403, 429):
                print(f"[!] {ticket['ticketName']} HTTP {code}"
                      f"（风控/限流），立即停止该票种，避免触发风控")
                return False
            if code == 400:
                # 400 可能是票种"在售/下架过渡状态"的临时错误，
                # 慢速重试有限次数（低频，不触发风控）
                print(f"[!] {ticket['ticketName']} HTTP 400"
                      f"（可能是票种状态过渡），3秒后重试（第{attempt}次）")
                time.sleep(3)
                continue
            print(f"[!] {ticket['ticketName']} 第{attempt}次请求异常: HTTP {code}")
            time.sleep(delay)
            continue
        except Exception as e:
            print(f"[!] {ticket['ticketName']} 第{attempt}次请求异常: {e}")
            time.sleep(delay)
            continue
        if data.get("isSuccess") and data.get("result"):
            print(f"[+] {ticket['ticketName']} 下单成功！（第{attempt}次尝试）")
            save_order(cfg, ticket, data["result"])
            return True
        msg = data.get("message", "")
        print(f"[{attempt}] {ticket['ticketName']}: {msg[:120]}")
        if not is_retryable(msg):
            if any(w in msg for w in
                   ["售罄", "售完", "无票", "余票", "库存", "抢完", "抢光", "卖完"]):
                print(f"[!] {ticket['ticketName']} 已判定售罄，切换下一个票种")
            else:
                print(f"[!] {ticket['ticketName']} 非可重试错误（可能是限购/参数问题），切换下一个票种")
            return False
        time.sleep(delay)
    print(f"[!] {ticket['ticketName']} 尝试 {max_attempts} 次未成功")
    return False


def wait_for_sale(sell_start_ms, offset_ms):
    """等待开售时间"""
    while True:
        now = int(time.time() * 1000) + offset_ms
        remain = sell_start_ms - now
        if remain <= 20:
            return
        if remain % 1000 < 50 or remain < 3000:
            print(f"[*] 距开售 {remain/1000:.1f} 秒")
        time.sleep(0.05)


def grab(cfg, offset_ms):
    """按优先级抢票：主目标成功后停止，否则依次尝试备选"""
    tickets = cfg.get("tickets", [])
    if not tickets:
        print("[!] 配置中没有票种")
        return []
    primary = tickets[0]
    start_str = time.strftime("%Y-%m-%d %H:%M:%S",
                              time.localtime(primary["sellStartTime"] / 1000))
    print(f"[*] 主目标: {primary['ticketName']} (ID={primary['ticketTypeId']})")
    print(f"[*] 开售时间: {start_str}")
    print(f"[*] 备选: " + ", ".join(
        f"{t['ticketName']}({t['ticketTypeId']})" for t in tickets[1:]))
    # 等待开售
    while True:
        now = int(time.time() * 1000) + offset_ms
        if now >= primary["sellStartTime"] - 20:
            break
        remain = primary["sellStartTime"] - now
        if remain % 1000 < 50 or remain < 3000:
            print(f"[*] 距开售 {remain/1000:.1f} 秒")
        time.sleep(0.05)
    print("[*] 开售！发送下单请求…")
    got = []
    for i, t in enumerate(tickets):
        print(f"[*] 第 {i+1}/{len(tickets)} 个票种: {t['ticketName']}")
        ok = try_ticket(cfg, t, offset_ms)
        if ok:
            got.append(t["ticketTypeId"])
            if t.get("role") == "primary":
                print("[+] 主目标已抢到，任务完成")
                return got
            print(f"[+] 备选 {t['ticketName']} 已抢到，继续下一个")
    if not got:
        print("[x] 所有票种均未成功")
        print("[*] 自动进入捡漏模式，持续监控余票（未支付订单过期会释放余票）")
        print("[*] 按 Ctrl+C 可随时停止")
        return watch(cfg, offset_ms)
    return got


def get_stock(cfg, ticket):
    """查询票种剩余库存"""
    try:
        tl = get_ticket_type_list(cfg)
        target = next((x for x in tl if x.get("id") == ticket["ticketTypeId"]), None)
        if target:
            return int(target.get("remainderNum", 0) or 0)
    except Exception as e:
        print(f"[!] 查询库存失败: {e}")
    return -1


def watch(cfg, offset_ms):
    """售罄后持续监控，有余票立即抢（捡漏模式）"""
    tickets = cfg.get("tickets", [])
    interval = cfg.get("watch_interval", 5)
    got = set()
    got_days = set()
    needed_days = {t.get("day") for t in tickets if t.get("day")}
    print(f"[*] 捡漏模式启动，每 {interval} 秒检查一次"
          f"（每轮仅 1 次查询，一次获取全部票种库存，Ctrl+C 停止）")
    while True:
        try:
            tl = get_ticket_type_list(cfg)
            stock_map = {
                t.get("id"): int(t.get("remainderNum", 0) or 0)
                for t in (tl or [])
            }
        except Exception as e:
            print(f"[!] 查询票种列表失败: {e}，稍后重试")
            time.sleep(interval)
            continue
        for t in tickets:
            if t["ticketTypeId"] in got:
                continue
            day = t.get("day", "")
            if day and day in got_days:
                continue
            stock = stock_map.get(t["ticketTypeId"], -1)
            if stock > 0:
                print(f"[*] {t['ticketName']} 有 {stock} 张余票，尝试下单！")
                if try_ticket(cfg, t, offset_ms,
                              max_attempts=cfg.get("watch_max_attempts", 2)):
                    got.add(t["ticketTypeId"])
                    if day:
                        got_days.add(day)
                    if t.get("role") == "primary":
                        print("[+] 主目标已抢到，捡漏完成")
                        return got
                    if needed_days and got_days >= needed_days:
                        print("[+] 所需天次均已抢到，捡漏完成")
                        return got
            else:
                print(f"[*] {t['ticketName']} 暂无余票"
                      + ("" if stock >= 0 else "（未在票种列表）"))
        time.sleep(interval)


def main():
    ap = argparse.ArgumentParser(description="CPP 抢票脚本")
    ap.add_argument("mode", nargs="?", default="grab",
                    choices=["verify", "selftest", "dryrun", "grab", "watch"])
    ap.add_argument("--config", default=CONFIG_PATH,
                    help="配置文件路径（默认 config.json）")
    ap.add_argument("--ticket", type=int, default=None,
                    help="只处理指定票种ID（如 6167），用于盯回流避免重复下单已抢到的票")
    args = ap.parse_args()
    if args.mode == "selftest":
        sys.exit(0 if selftest() else 1)
    cfg = load_config(args.config)
    if args.mode == "dryrun":
        sys.exit(0 if dryrun(cfg) else 1)
    if args.mode == "verify":
        ok = verify_tickets(cfg) and verify_purchasers(cfg)
        sys.exit(0 if ok else 1)
    if args.ticket:
        before = len(cfg.get("tickets", []))
        cfg["tickets"] = [t for t in cfg.get("tickets", [])
                          if t["ticketTypeId"] == args.ticket]
        if not cfg["tickets"]:
            print(f"[!] 配置中不存在票种 ID={args.ticket}")
            sys.exit(1)
        print(f"[*] 仅处理票种 ID={args.ticket}（原 {before} 个，已过滤）")
    # grab / watch
    if not (verify_tickets(cfg) and verify_purchasers(cfg)):
        sys.exit(1)
    offset_ms = sync_time(cfg)
    if args.mode == "watch":
        watch(cfg, offset_ms)
    else:
        grab(cfg, offset_ms)


if __name__ == "__main__":
    main()
